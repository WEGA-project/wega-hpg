## Телеграм: https://t.me/ponics_ru

#### Используя этот профиль это не гарантия успеха, нужно понимать что вы делаете и как.

#### Автор профиля

Dmitriy Burakov

#### Где и как найти дополнительную информацию

Искать результат выращивания клубники на этом профиле в канале по хештегам

* #Питание
* #Клубника
* #настоящая
* #гидропоника

#### Фото
<a href="s_1.jpg"><img src="s_1.jpg" width="250"></a><a href="s_2.jpg"><img src="s_2.jpg" width="250"></a>

<a href="s_3.jpg"><img src="s_3.jpg" width="250"></a><a href="s_4.jpg"><img src="s_4.jpg" width="250"></a>

<a href="s_5.jpg"><img src="s_5.jpg" width="250"></a><a href="s_6.jpg"><img src="s_6.jpg" width="250"></a>
