## Телеграм: https://t.me/ponics_ru

#### Используя этот профиль это не гарантия успеха, нужно понимать что вы делаете и как.

#### Автор профиля

Dmitriy Burakov

#### Где и как найти дополнительную информацию

Искать результат выращивания клубники на этом профиле в канале по хештегам

* #Питание
* #Клубника
* #настоящая
* #гидропоника

#### Фото
<a href="img/s_1.jpg"><img src="img/s_1.jpg" width="250"></a><a href="img/s_2.jpg"><img src="img/s_2.jpg" width="250"></a>

<a href="img/s_3.jpg"><img src="img/s_3.jpg" width="250"></a><a href="img/s_4.jpg"><img src="img/s_4.jpg" width="250"></a>

<a href="img/s_5.jpg"><img src="img/s_5.jpg" width="250"></a><a href="img/s_6.jpg"><img src="img/s_6.jpg" width="250"></a>
