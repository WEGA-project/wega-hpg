# Telegram: https://t.me/ponics_ru

### Используя этот профиль это не гарантия успеха, нужно понимать что вы делаете и как.

## Автор профиля

@meklon

## Где и как найти дополнительную информацию

Искать результат выращивания перца на этом профиле в канале по хештегам и по имени автора.

* #Перец

## Стадии роста

### Вега
Активный рост и набор зеленой масы

### Поздняя вега
Когда куст уже заполнил корнями объем и начал активно наращивать массу. 

В этом профиле у него резко усиливается площадь листа и скорость роста при достаточном свете.

### Плодоношение
Активное цветение и плодоношение 

### Фото
<a href="img/p_1.jpg"><img src="img/p_1.jpg" width="250"><a href="img/p_3.jpg"><img src="img/p_3.jpg" width="250"></a>

</a><a href="img/p_2.jpg"><img src="img/p_2.jpg" width="250"></a><a href="img/p_4.jpg"><img src="img/p_4.jpg" width="250"></a>

### Видео
[![Trinidad Scorpion CARDI](https://img.youtube.com/vi/AOksTldICkg/0.jpg)](https://www.youtube.com/watch?v=AOksTldICkg "Trinidad Scorpion CARDI")
